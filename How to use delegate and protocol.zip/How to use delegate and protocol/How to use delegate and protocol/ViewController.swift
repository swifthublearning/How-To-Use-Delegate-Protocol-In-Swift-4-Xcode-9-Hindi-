//
//  ViewController.swift
//  How to use delegate and protocol
//
//  Created by Abhishek Verma on 14/04/18.
//  Copyright © 2018 Abhishek Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController, dataprotocol {

    
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var AddressLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func AddNameaddress(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "SecondClassViewController") as! SecondClassViewController
        vc.delegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func proto(name: String, address: String) {
        NameLabel.text = "Name : \(name)"
        AddressLabel.text = "Address : \(address)"
    }
    
    
}

